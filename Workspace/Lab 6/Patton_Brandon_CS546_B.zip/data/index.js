const bandData = require("./bands");
const albumData = require("./albums");

module.exports = {
  bands: bandData,
  albums: albumData
};